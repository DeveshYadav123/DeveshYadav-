# Viva Voce Questions and Answers

1. **What is Artificial Intelligence?**  
   AI is the field of building systems that perform tasks normally requiring human-like intelligence.

2. **What is Machine Learning?**  
   ML is a branch of AI in which systems learn patterns from data.

3. **What is supervised learning?**  
   Learning from labelled examples where the correct target is known.

4. **Why is this a regression problem?**  
   The target `G3` is a numeric final grade, not a category.

5. **What is the target variable?**  
   `G3`, the final Mathematics grade.

6. **Why are G1 and G2 excluded?**  
   They are earlier-period grades strongly associated with G3. Excluding them avoids grade-based target leakage and makes the prediction task more meaningful.

7. **What is data preprocessing?**  
   Preparing raw data for modelling by cleaning, imputing, encoding and transforming features.

8. **Why is one-hot encoding used?**  
   It converts nominal categories into numeric indicator columns without imposing an artificial order.

9. **Why use median imputation for numeric columns?**  
   The median is less affected by extreme values than the mean.

10. **What is a train-test split?**  
    Dividing data into training records for fitting and test records for evaluating performance on unseen records.

11. **What is Random Forest?**  
    An ensemble algorithm that averages predictions from many decision trees trained on varied samples/features.

12. **Why compare multiple models?**  
    No algorithm is guaranteed to perform best on every dataset; comparison supports an evidence-based choice.

13. **What is MAE?**  
    Mean Absolute Error; the average absolute difference between actual and predicted values.

14. **What is RMSE?**  
    Root Mean Squared Error; it penalises larger errors more strongly than MAE.

15. **What is R-squared?**  
    A metric comparing model predictions with a mean-prediction baseline. It can be negative on test data.

16. **What is overfitting?**  
    When a model learns training-specific patterns and performs poorly on unseen data.

17. **What is cross-validation?**  
    Repeated training/validation across folds to estimate model stability.

18. **What is correlation?**  
    A measure of association between variables; correlation does not prove causation.

19. **What is target leakage?**  
    When information unavailable or inappropriate at prediction time is included in training features.

20. **What are the limitations?**  
    The dataset is small, historical and from two Portuguese schools, so results may not generalise.
