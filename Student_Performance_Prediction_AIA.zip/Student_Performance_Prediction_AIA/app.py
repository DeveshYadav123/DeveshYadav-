"""Optional Streamlit interface for the AIA Student Performance project."""
from pathlib import Path
import json
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "student-mat.csv"
MODEL = ROOT / "models" / "best_model.joblib"
OUT = ROOT / "outputs"

st.set_page_config(page_title="Student Performance AI", page_icon="🎓", layout="wide")
st.title("🎓 Student Performance Prediction")
st.caption("AIA College Project | Machine Learning Regression Demonstration")

if not MODEL.exists() or not DATA.exists():
    st.warning("Run `python main.py` first. It downloads the dataset, trains models and saves the selected model.")
    st.code("pip install -r requirements.txt\npython main.py\nstreamlit run app.py", language="bash")
    st.stop()

df = pd.read_csv(DATA, sep=";")
model = joblib.load(MODEL)
summary_path = OUT / "evaluation_summary.json"
summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}

tab1, tab2, tab3 = st.tabs(["Project overview", "Dataset explorer", "Grade prediction"])
with tab1:
    c1, c2, c3 = st.columns(3)
    c1.metric("Student records", len(df))
    c2.metric("Original attributes", df.shape[1])
    c3.metric("Target", "G3 / 20")
    st.write("This demonstration predicts the final Mathematics grade using non-grade attributes. Earlier grades G1 and G2 are intentionally excluded.")
    if summary:
        st.subheader("Model evaluation")
        st.write("Selected model:", summary.get("best_model_by_test_MAE", "Run pipeline to populate"))
        results_file = OUT / "model_comparison.csv"
        if results_file.exists():
            st.dataframe(pd.read_csv(results_file), use_container_width=True)
    for img in ["model_comparison.png", "correlation_heatmap.png", "actual_vs_predicted.png"]:
        path = OUT / img
        if path.exists():
            st.image(str(path), caption=img.replace("_", " ").replace(".png", "").title(), use_container_width=True)

with tab2:
    st.subheader("Dataset preview")
    st.dataframe(df.head(30), use_container_width=True)
    st.write("Missing values by column")
    st.dataframe(df.isna().sum().rename("Missing values").to_frame(), use_container_width=True)
    st.download_button("Download source CSV", DATA.read_bytes(), file_name="student-mat.csv", mime="text/csv")

with tab3:
    st.write("Edit the student profile below. G1 and G2 are not used by this model.")
    feature_df = df.drop(columns=["G1", "G2", "G3"])
    defaults = feature_df.mode(dropna=True).iloc[0]
    with st.form("prediction_form"):
        user_values = {}
        numeric_cols = feature_df.select_dtypes(include="number").columns.tolist()
        categorical_cols = feature_df.select_dtypes(exclude="number").columns.tolist()
        with st.expander("Numeric attributes", expanded=True):
            cols = st.columns(3)
            for i, col in enumerate(numeric_cols):
                val = float(feature_df[col].median())
                user_values[col] = cols[i % 3].number_input(col, value=val, key=f"num_{col}")
        with st.expander("Categorical attributes", expanded=False):
            cols = st.columns(3)
            for i, col in enumerate(categorical_cols):
                choices = sorted(feature_df[col].dropna().astype(str).unique().tolist())
                default = str(defaults[col])
                idx = choices.index(default) if default in choices else 0
                user_values[col] = cols[i % 3].selectbox(col, choices, index=idx, key=f"cat_{col}")
        submitted = st.form_submit_button("Predict final grade")
    if submitted:
        input_df = pd.DataFrame([user_values], columns=feature_df.columns)
        prediction = float(model.predict(input_df)[0])
        st.success(f"Estimated final Mathematics grade: {prediction:.1f} / 20")
        st.caption("This is an educational model estimate, not an official grade or a judgement of a student's ability.")
